package com.devtiro.task.service.impl;

import java.time.Instant;

import org.springframework.stereotype.Service;

import com.devtiro.task.domain.CreateTaskRequest;
import com.devtiro.task.domain.entity.Task;
import com.devtiro.task.domain.entity.TaskStatus;
import com.devtiro.task.repository.TaskRepository;
import com.devtiro.task.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService {

    private final TaskRepository taskRepository;

    public TaskServiceImpl(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    @Override
    public Task createTask(CreateTaskRequest request) {
        Instant now = Instant.now();

        Task task = new Task(
            null,
            request.title(),
            request.description(),
            request.dueDate(),
            TaskStatus.OPEN,
            request.priority(),
            now,
            now
        );

        return taskRepository.save(task);
    }
}
